# ⚡ DailyUse — AI-Powered Productivity Platform

A complete, enterprise-grade productivity application with AI assistance, task management, habit tracking, notes, Pomodoro timer, calendar, analytics, and gamification.

---

## 🚀 Quick Start (Open in Browser — No Setup Required)

```bash
# Option 1: Open directly
open index.html

# Option 2: Local server (recommended)
npx live-server --port=8080

# Option 3: Python server
python3 -m http.server 8080
```
Then visit: **http://localhost:8080**

---

## 📁 Project Structure

```
DailyUse/
├── index.html              # Main HTML — all views & modals
│
├── css/
│   ├── main.css            # Core layout, base styles, variables
│   ├── animations.css      # All keyframes & transitions
│   ├── themes.css          # Dark/Light/AMOLED, accent colors
│   └── components.css      # Reusable UI components
│
├── js/
│   ├── storage.js          # LocalStorage persistence layer
│   ├── utils.js            # Utility functions (dates, IDs, etc.)
│   ├── state.js            # Global app state manager (CRUD)
│   ├── tasks.js            # Task rendering & task modal
│   ├── habits.js           # Habit tracker UI
│   ├── notes.js            # Notes & rich text editor
│   ├── pomodoro.js         # Focus timer logic
│   ├── calendar.js         # Monthly/weekly calendar
│   ├── analytics.js        # Charts (Chart.js)
│   ├── ai.js               # AI Assistant (Claude API)
│   ├── gamification.js     # XP, levels, badges, streaks
│   ├── notifications.js    # In-app & push notifications
│   ├── search.js           # Global search & voice search
│   ├── animations.js       # Confetti, transitions, effects
│   ├── settings.js         # Settings, themes, data export
│   └── app.js              # Main controller & event binding
│
├── ts/
│   ├── types.ts            # TypeScript type definitions
│   ├── api-client.ts       # TypeScript API client
│   └── hooks.ts            # React hooks (for future React version)
│
├── python/
│   ├── ai_service.py       # Python AI service (Claude API)
│   └── analytics.py        # Analytics engine & CSV export
│
├── backend/
│   ├── server.js           # Node.js/Express REST API
│   └── database.js         # MongoDB, PostgreSQL, SQLite, Redis schemas
│
└── config/
    ├── package.json        # Node.js dependencies
    ├── tsconfig.json       # TypeScript configuration
    └── .env.example        # Environment variables template
```

---

## ✨ Features

### Core
- ✅ Create, edit, delete, archive tasks
- ✅ Priority levels (High / Medium / Low)
- ✅ Due dates & times with overdue detection
- ✅ Subtasks with progress bar
- ✅ Tags, categories, color labels
- ✅ Favorites & recurring tasks
- ✅ Drag-to-organize (visual feedback)
- ✅ Archive & Trash with restore
- ✅ Full-text search + voice search

### AI Features
- ✅ AI Chat Assistant (Claude-powered)
- ✅ AI Daily/Weekly Planner
- ✅ AI Task Subtask Generator
- ✅ AI Note Summarizer
- ✅ AI Workload Analysis
- ✅ AI Burnout Detector
- ✅ AI Goal Planning
- ✅ AI Time Blocking
- ✅ AI Dashboard Suggestions

### Personal Productivity
- ✅ Habit Tracker with streaks & heatmap
- ✅ Pomodoro Focus Timer (25/5/15 min)
- ✅ Rich Text Notes Editor
- ✅ Monthly/Weekly Calendar
- ✅ Productivity Analytics (Chart.js)
- ✅ Gamification (XP, Levels, 17 Badges)
- ✅ Push Notifications & Reminders

### UI/UX
- ✅ Dark / Light / AMOLED themes
- ✅ 5 accent colors (Purple, Blue, Green, Orange, Neon)
- ✅ Glassmorphism design
- ✅ Smooth animations & confetti
- ✅ Collapsible sidebar
- ✅ Fully responsive (mobile-first)
- ✅ Keyboard shortcuts (Ctrl+N, Ctrl+K)

### Data
- ✅ LocalStorage persistence (works offline)
- ✅ JSON export / import
- ✅ Data reset

---

## 🔑 Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+N` | New Task |
| `Ctrl+K` | Search |
| `Escape` | Close Modal |

---

## 🛠 Backend Setup (Optional)

```bash
cd DailyUse
cp config/.env.example .env
# Edit .env with your API keys

npm install
npm run dev
# API runs on http://localhost:3001
```

---

## 🤖 AI Setup

Add your Anthropic API key to `.env`:
```
ANTHROPIC_API_KEY=sk-ant-...
```

The app works without an API key using built-in fallback responses.

---

## 🐍 Python AI Service (Optional)

```bash
pip install anthropic
python python/ai_service.py
```

---

## 🌐 GitHub Pages Deployment

```bash
git init
git add .
git commit -m "Initial DailyUse app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dailyuse.git
git push -u origin main
# Enable GitHub Pages → Settings → Pages → Branch: main → / (root)
```

---

## 📱 Browser Support
Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

## 📄 License
MIT — Free to use, modify, and distribute.
